package application2;

public class ResultatsUniteEnseignement {
	private String nom;	// donne le nom de la matière
	private Note note;	// donne la note d'un étudiant
	
	public ResultatsUniteEnseignement(String nom, Note note) {
		super();
		this.nom = nom;
		this.note = note;
	}
	public Note getNote() {
		return note;
	}
	public String toString() {
		return this.nom+" : "+note;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}

}
