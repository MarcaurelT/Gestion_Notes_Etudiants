package application2;
public class Note {
	private static final int NOTE_MAXIMUM = 20 ;
	private double valeur;		// La valeur de la note
	private boolean estAbsent ; // true si pas de note
	
	// Constructeur par défaut
	public Note() {
		super();
		this.valeur=0;
		this.estAbsent=true;
	}
	// Constructeur complet
	public Note(double valeur, boolean estAbsent) {
		this();// Appel du constructeur par défaut 
		if(valeur>=0 && valeur <=NOTE_MAXIMUM) {
			this.valeur = valeur;
			this.estAbsent = estAbsent;
		}
		else
		{
			System.out.println("La note doit être entre 0 et "+NOTE_MAXIMUM);
		}	
	}
	public Note(double valeur) {
		this(valeur, false); // Appel du constructeur complet
	}
	public boolean isAbsent() {
		return estAbsent ;
	}
	// Getteur, accesseur
	public double getValeur() {
		return valeur;
	}
	@Override
	public String toString() {
		if (estAbsent) {
			return "ABS";
		}
		return this.valeur+"/20";
	}
	
	public boolean isEstAbsent() {
		return estAbsent;
	}
	public void setEstAbsent(boolean estAbsent) {
		this.estAbsent = estAbsent;
	}
	public void setValeur(double valeur) {
		this.valeur = valeur;
	}
}
