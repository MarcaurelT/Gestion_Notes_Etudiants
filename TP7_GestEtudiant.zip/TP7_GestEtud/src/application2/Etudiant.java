package application2;

import java.util.ArrayList;
import java.util.List;

public class Etudiant {
	private String nom;
	private String prenom;
	
	// Liste des matières enseignées
	private List<ResultatsUniteEnseignement> tabUE = new ArrayList<>();
	public Etudiant(String nom, String prenom) {
		this.nom = nom;
		this.prenom = prenom;
	}
	
	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public List<ResultatsUniteEnseignement> getTabUE() {
		return tabUE;
	}

	public void addResultat(String nomUniteEnseignement, Note note) {
		ResultatsUniteEnseignement tmp = new ResultatsUniteEnseignement(nomUniteEnseignement,  note);
		// insérer tmp 
		tabUE.add(tmp);
		
	}
	
	// Retourne la liste des notes
	public List<Note> getNotes(){
		List<Note> lNotes = new ArrayList<Note>() ;
		for(ResultatsUniteEnseignement r : tabUE) {
			lNotes.add(r.getNote());
		}
		return lNotes;
	}
	public static Note moyenneNotes(List<Note> notes) {
		Note moy = new Note();
		double m = 0.0;
		for(Note n : notes) {
			if(n.isAbsent()) {
				return moy;
			}
			m+=n.getValeur();
		}
		m/=notes.size();
		moy=new Note(m);
		return moy;
	}
	
	// Retourne la moyennes d'un étudiant 
	public Note moyenneNotes() {
		return moyenneNotes(this.getNotes());
	}
	public String toString() {
		String ch="";
		ch="Notes de "+nom+" "+prenom+" :\n";
		ch+=tabUE;
		return ch;
	}
}
