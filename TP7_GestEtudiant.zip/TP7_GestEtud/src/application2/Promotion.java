package application2;

import java.util.ArrayList;
import java.util.List;

public class Promotion {
	private String nom;
	
	
	
	public Promotion(String nom, List<Etudiant> etudiants) {
		super();
		this.nom = nom;
		this.etudiants = etudiants;
	}
	// Liste des étudiants qui composent la promotion
	private List<Etudiant> etudiants = new ArrayList<Etudiant>();
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public List<Etudiant> getEtudiants() {
		return etudiants;
	}
	public void setEtudiants(List<Etudiant> etudiants) {
		this.etudiants = etudiants;
	}
	
}
