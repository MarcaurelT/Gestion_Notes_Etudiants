package application;

import java.util.ArrayList;
import java.util.List;

import application2.Etudiant;
import application2.Promotion;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class SaisieNoteController {
	@FXML
	private int indice;
	@FXML
	private Etudiant etudiantCourant;
	@FXML
	private Promotion promo3iL ;
	@FXML
	private TextField t_id;
	
	@FXML
	private Button actionprecedant;
	
	@FXML
	private Button actionpSuivant;
	
	@FXML
	private Button actionsaisir;
	
	public SaisieNoteController() {
		
	}
	public SaisieNoteController(int indice, Etudiant etudiantCourant, Promotion promo3iL) {
		super();
		this.indice = indice;
		this.etudiantCourant = etudiantCourant;
		this.promo3iL = promo3iL;
	}

	//methode charger infos
	
	public  void chargerInfos(){
		Etudiant e1 = new Etudiant("Boulanger","Paul");
		Etudiant e2 = new Etudiant("Karim","Abdel");
		List<Etudiant> etuProm = new ArrayList();
		etuProm.add(e2);
		etuProm.add(e1);
		Promotion prom = new Promotion("Prom3iL",etuProm);
		 
		//manque cbUniteEnseignement
		
		
		
		//remplir le combo box
		
//		cbUniteEnseignement.getItems().selectAll(uniEns);
//		cbUniteEnseignement.getSelectModel().getSelectIndex();
		
	}
	
	
	
}
